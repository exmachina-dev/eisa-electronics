README for GRB-27182_C.zip

Company Part Number: 170-27182 REV C

Date : 12/13/2011 01:57:28

Freescale Semiconductor
7700 West Parmer Lane
Austin, TX 78729
Maildrop: PL59

Company Contact: Li Clara
	Work Phone: +86-21-2893 7043
		 Email:	 B14602@freescale.com